import { GalleryComponent } from './gallery.js';
import { EditorComponent, initToastEditor } from './editor.js';

const { Juris } = window;

// --- COMPONENTS ---

const SidebarComponent = (props, context) => ({
    render: () => {
        const menuOpen = context.getState('menuOpen', false);
        const advOpen = context.getState('advancedSearchOpen', false);
        const searchQuery = context.getState('searchQuery', '');
        
        return {
            aside: {
                id: 'sidebar',
                class: 'sidebar',
                children: () => [
                    {
                        div: {
                            id: 'sidebar-header',
                            class: 'sidebar-header',
                            children: () => [
                                {
                                    div: {
                                        id: 'menu-container',
                                        class: 'menu-container',
                                        children: () => [
                                            { button: { id: 'btn-menu', title: 'Menu', onclick: () => context.setState('menuOpen', !menuOpen), children: () => [{ span: { class: 'material-symbols-rounded', text: 'menu' } }] } },
                                            {
                                                div: {
                                                    id: 'menu-dropdown',
                                                    class: `dropdown-content ${menuOpen ? '' : 'hidden'}`,
                                                    children: () => [
                                                        { button: { id: 'btn-sync', title: 'Sync Files', onclick: () => handleSync(context), children: () => [{ span: { class: 'material-symbols-rounded', text: 'sync' } }, { span: { text: ' Sync Data' } }] } }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                { button: { id: 'btn-new', title: 'New Note', onclick: () => context.setState('isCreatingNote', true), children: () => [{ span: { class: 'material-symbols-rounded', text: 'add' } }] } },
                                {
                                    div: {
                                        id: 'search-container',
                                        class: 'search-container',
                                        children: () => [
                                            {
                                                div: {
                                                    id: 'search-main',
                                                    class: 'search-main',
                                                    children: () => [
                                                        {
                                                            div: {
                                                                id: 'search-input-wrapper',
                                                                class: 'search-input-wrapper',
                                                                children: () => [
                                                                    { input: { id: 'search-bar', type: 'text', placeholder: 'Search...', value: searchQuery, oninput: (e) => { context.setState('searchQuery', e.target.value); triggerSearch(context); } } },
                                                                    { button: { id: 'btn-clear-search', class: `btn-clear-search ${searchQuery ? '' : 'hidden'}`, title: 'Clear', onclick: () => { context.setState('searchQuery', ''); performSearch(context); }, children: () => [{ span: { class: 'material-symbols-rounded', text: 'close' } }] } }
                                                                ]
                                                            }
                                                        },
                                                        { button: { id: 'btn-toggle-advanced', title: 'Toggle Advanced Search', onclick: () => {
                                                            const willClose = advOpen;
                                                            context.setState('advancedSearchOpen', !advOpen);
                                                            if (willClose) {
                                                                context.setState('searchType', '');
                                                                context.setState('searchTag', '');
                                                                performSearch(context);
                                                            }
                                                        }, children: () => [{ span: { class: 'material-symbols-rounded', text: 'tune' } }] } }
                                                    ]
                                                }
                                            },
                                            {
                                                div: {
                                                    id: 'advanced-search',
                                                    class: `advanced-search ${advOpen ? '' : 'hidden'}`,
                                                    children: () => [
                                                        {
                                                            select: {
                                                                id: 'type-filter',
                                                                value: context.getState('searchType', ''),
                                                                onchange: (e) => { context.setState('searchType', e.target.value); performSearch(context); },
                                                                children: () => [
                                                                    { option: { value: '', text: 'All Types' } },
                                                                    ...context.getState('types', []).map(t => ({ option: { value: t, text: t.charAt(0).toUpperCase() + t.slice(1) } }))
                                                                ]
                                                            }
                                                        },
                                                        { input: { id: 'tag-filter', type: 'text', placeholder: 'Filter by #tag', value: context.getState('searchTag', ''), oninput: (e) => { context.setState('searchTag', e.target.value); triggerSearch(context); } } },
                                                        { button: { id: 'btn-save-search', class: 'btn-save-search', title: 'Save Search', onclick: () => handleSaveSearch(context), children: () => [{ span: { class: 'material-symbols-rounded', text: 'bookmark' } }, { span: { text: ' Save Search' } }] } }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    GalleryComponent(props, context).render()
                ]
            }
        };
    }
});

const ResizerComponent = (props, context) => ({
    render: () => ({
        div: {
            id: 'sidebar-resizer',
            class: 'resizer',
            onmousedown: (e) => {
                document.body.style.cursor = 'col-resize';
                
                const handleMouseMove = (e) => {
                    let newWidth = e.clientX;
                    if (newWidth < 250) newWidth = 250;
                    if (newWidth > 600) newWidth = 600;
                    context.setState('sidebarWidth', newWidth);
                };
                
                const handleMouseUp = () => {
                    document.body.style.cursor = 'default';
                    localStorage.setItem('sidebar-width', context.getState('sidebarWidth', 250));
                    window.removeEventListener('mousemove', handleMouseMove);
                    window.removeEventListener('mouseup', handleMouseUp);
                };
                
                window.addEventListener('mousemove', handleMouseMove);
                window.addEventListener('mouseup', handleMouseUp);
            }
        }
    })
});

const CreateNoteComponent = (props, context) => ({
    render: () => {
        return {
            div: {
                class: 'create-view',
                children: () => [
                    {
                        div: {
                            class: 'create-form',
                            children: () => [
                                { h2: { style: { marginTop: '0', textAlign: 'center' }, text: 'New Note' } },
                                { input: { type: 'text', id: 'new-title', placeholder: 'Title', oninput: e => context.setState('newNoteTitle', e.target.value) } },
                                {
                                    div: {
                                        style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' },
                                        children: () => [
                                            { button: { class: 'btn-primary', text: 'Create', onclick: () => submitNewObject(context) } },
                                            { button: { text: 'Cancel', onclick: () => context.setState('isCreatingNote', false) } }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        };
    }
});

const AppPage = (props, context) => ({
    render: () => {
        if (context.getState('isCreatingNote', false)) {
            return CreateNoteComponent(props, context).render();
        }
        
        return {
            div: {
                class: `app-container ${context.getState('currentNote') ? 'show-editor' : ''}`,
                id: 'app',
                style: { gridTemplateColumns: `${context.getState('sidebarWidth', 250)}px 12px 1fr` },
                children: () => [
                    SidebarComponent(props, context).render(),
                    ResizerComponent(props, context).render(),
                    EditorComponent(props, context).render()
                ]
            }
        };
    }
});

// --- ACTIONS ---

async function fetchObjects(context) {
    const res = await fetch('/api/objects');
    context.setState('objects', await res.json());
}

async function fetchTypes(context) {
    const res = await fetch('/api/types');
    context.setState('types', await res.json());
}

let searchTimeout;
function triggerSearch(context) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => performSearch(context), 300);
}

async function performSearch(context) {
    const query = context.getState('searchQuery', '');
    const type = context.getState('searchType', '');
    const tag = context.getState('searchTag', '');
    
    try {
        const url = `/api/search?q=${encodeURIComponent(query)}&type=${encodeURIComponent(type)}&tag=${encodeURIComponent(tag)}`;
        const res = await fetch(url);
        const data = await res.json();
        
        if (Array.isArray(data)) {
            context.setState('objects', data);
        } else {
            console.error("Search Error:", data.error);
            context.setState('objects', []);
        }
    } catch (err) {
        console.error("Fetch Error:", err);
        context.setState('objects', []);
    }
}

async function handleSync(context) {
    await fetch('/api/sync', { method: 'POST' });
    await fetchObjects(context);
}

async function submitNewObject(context) {
    const title = context.getState('newNoteTitle', '');
    if (!title) return alert("Please enter a title.");
    
    const res = await fetch('/api/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, type: 'note', variables: {} })
    });
    
    if (res.ok) {
        const result = await res.json();
        context.setState('isCreatingNote', false);
        await fetchObjects(context);
        
        // Auto-switch to newly created note in edit mode
        const createdObj = context.getState('objects').find(o => o.id === result.id);
        if (createdObj) {
            context.setState('currentNote', createdObj);
            context.setState('isEditMode', true);
            setTimeout(() => initToastEditor(createdObj, context), 0);
        }
    }
}

async function handleSaveSearch(context) {
    const query = context.getState('searchQuery', '');
    const type = context.getState('searchType', '');
    const tag = context.getState('searchTag', '');
    if (!query && !type && !tag) return alert("Search is empty.");
    
    const title = prompt("Enter a name for this saved search:", "My Search");
    if (!title) return;
    
    const res = await fetch('/api/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, type: 'query' })
    });
    
    if (res.ok) {
        const result = await res.json();
        await fetch('/api/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                id: result.id, 
                content: `Search: Query: ${query}, Type: ${type}, Tag: ${tag}`, 
                metadata: { title, type: 'query', search_query: query, search_type: type, search_tag: tag }
            })
        });
        await fetchObjects(context);
    }
}

// --- INIT ---

const jurisApp = new Juris({
    renderMode: 'fine-grained',
    states: {
        objects: [],
        types: [],
        sidebarWidth: parseInt(localStorage.getItem('sidebar-width') || '250', 10),
        menuOpen: false,
        advancedSearchOpen: false,
        isCreatingNote: false,
        searchQuery: '',
        searchType: '',
        searchTag: '',
        currentNote: null,
        isEditMode: false,
        newNoteTitle: '',
        selectedTemplate: ''
    },
    components: { AppPage },
    layout: { AppPage: {} }
});

fetchObjects(jurisApp);
fetchSettings(jurisApp);
fetchTypes(jurisApp);

// Mount the application to the DOM
jurisApp.render('#juris-app-root');

// Handle opening notes from dataview links
window.addEventListener('open-note', async (e) => {
    const { id } = e.detail;
    const res = await fetch('/api/objects');
    const objects = await res.json();
    jurisApp.setState('objects', objects);
    const obj = objects.find(o => o.id === id);
    if (obj) {
        jurisApp.setState('currentNote', obj);
        jurisApp.setState('isEditMode', false);
        setTimeout(() => initToastEditor(obj, jurisApp), 0);
    }
});

// Expose dispatching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
  jurisApp.setState('currentNote', obj);
        jurisApp.setState('isEditMode', false);
        setTimeout(() => initToastEditor(obj, jurisApp), 0);
    }
});

// Expose dispatching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
tching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
EventListener('open-note', async (e) => {
    const { id } = e.detail;
    const res = await fetch('/api/objects');
    const objects = await res.json();
    jurisApp.setState('objects', objects);
    const obj = objects.find(o => o.id === id);
    if (obj) {
        jurisApp.setState('currentNote', obj);
        jurisApp.setState('isEditMode', false);
        setTimeout(() => initToastEditor(obj, jurisApp), 0);
    }
});

// Expose dispatching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
  jurisApp.setState('currentNote', obj);
        jurisApp.setState('isEditMode', false);
        setTimeout(() => initToastEditor(obj, jurisApp), 0);
    }
});

// Expose dispatching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
tching for sub-components (gallery triggers)
window.addEventListener('trigger-search', () => performSearch(jurisApp));
export default jurisApp;
