let editorInstance = null;
let viewerInstance = null;

function getInputType(key, value) {
    const k = key.toLowerCase();
    if (k.includes('date') || (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value))) return 'date';
    if (typeof value === 'boolean') return 'checkbox';
    if (typeof value === 'number') return 'number';
    return 'text';
}

export const EditorComponent = (props, context) => ({
    render: () => {
        const note = context.getState('currentNote', null);
        const isEditMode = context.getState('isEditMode', false);
        const metaVisible = context.getState('metaVisible', false);

        let metadata = {};
        if (note) {
            metadata = typeof note.metadata === 'string' ? JSON.parse(note.metadata) : (note.metadata || {});
        }

        const updateMeta = (key, value) => {
            const updatedMeta = { ...metadata, [key]: value };
            context.setState('currentNote', { ...note, metadata: updatedMeta });
        };

        const deleteMeta = (key) => {
            const updatedMeta = { ...metadata };
            delete updatedMeta[key];
            context.setState('currentNote', { ...note, metadata: updatedMeta });
        };

        const addMetaProp = () => {
            const newKey = prompt("Property name:");
            if (newKey && !newKey.startsWith('_')) {
                updateMeta(newKey, "");
                context.setState('metaVisible', true);
            }
        };

        if (!note) {
            return {
                main: {
                    class: 'editor-view',
                    children: () => [
                        {
                            div: {
                                id: 'editor-placeholder',
                                class: 'empty-state',
                                children: () => [
                                    { div: { class: 'empty-state-content', children: () => [{ span: { class: 'empty-state-icon', text: '📝' } }, { p: { text: 'Select a note from the sidebar to start editing' } }] } }
                                ]
                            }
                        }
                    ]
                }
            };
        }

        return {
            main: {
                class: 'editor-view',
                children: () => [
                    {
                        div: {
                            id: 'editor-container',
                            children: () => [
                                {
                                    div: {
                                        class: 'editor-header',
                                        children: () => [
                                            { button: { title: 'Close', onclick: () => context.setState('currentNote', null), children: () => [{ span: { class: 'material-symbols-rounded', text: 'close' } }] } },
                                            { button: { class: isEditMode ? 'hidden' : 'btn-primary', title: 'Edit', onclick: () => context.setState('isEditMode', true), children: () => [{ span: { class: 'material-symbols-rounded', text: 'edit' } }] } },
                                            { button: { class: isEditMode ? '' : 'hidden', title: 'View', onclick: () => syncViewMode(context), children: () => [{ span: { class: 'material-symbols-rounded', text: 'visibility' } }] } },
                                            { button: { class: isEditMode ? '' : 'hidden', title: 'Save', onclick: () => saveNoteContent(context), children: () => [{ span: { class: 'material-symbols-rounded', text: 'save' } }] } }
                                        ]
                                    }
                                },
                                {
                                    div: {
                                        class: `metadata-form ${isEditMode ? '' : 'view-only'}`,
                                        children: () => [
                                            {
                                                div: {
                                                    class: 'meta-header',
                                                    onclick: (e) => {
                                                        if (!e.target.closest('#btn-add-prop')) {
                                                            context.setState('metaVisible', !metaVisible);
                                                        }
                                                    },
                                                    children: () => [
                                                        { h2: { class: 'meta-title', children: () => [{ span: { class: 'material-symbols-rounded meta-toggle-icon', style: { transform: metaVisible ? 'rotate(0deg)' : 'rotate(-90deg)', display: 'inline-block', transition: 'transform 0.2s' }, text: 'expand_more' } }, { span: { text: note.title } }] } },
                                                        { button: { id: 'btn-add-prop', class: 'btn-add-prop', onclick: addMetaProp, children: () => [{ span: { class: 'material-symbols-rounded', style: { fontSize: '1rem' }, text: 'add' } }, { span: { text: ' Property' } }] } }
                                                    ]
                                                }
                                            },
                                            {
                                                div: {
                                                    id: 'fields-container',
                                                    class: metaVisible ? '' : 'hidden',
                                                    children: () => Object.entries(metadata).filter(([key]) => !key.startsWith('_')).map(([key, value]) => {
                                                        const type = getInputType(key, value);
                                                        let displayValue = value;
                                                        if (value instanceof Date) displayValue = value.toISOString().split('T')[0];
                                                        return {
                                                            div: {
                                                                class: 'meta-field',
                                                                children: () => [
                                                                    { label: { class: 'meta-label', text: `${key}:` } },
                                                                    { input: { type, class: `meta-input meta-input-${type}`, 'data-key': key, value: displayValue, checked: type === 'checkbox' ? value : undefined, oninput: e => updateMeta(key, type === 'checkbox' ? e.target.checked : (type === 'number' ? Number(e.target.value) : e.target.value)) } },
                                                                    { button: { class: 'delete-prop btn-delete-prop', title: 'Delete Property', onclick: () => deleteMeta(key), text: '✕' } }
                                                                ]
                                                            }
                                                        };
                                                    })
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    div: { id: 'body-viewer', class: isEditMode ? 'hidden' : 'body-viewer' }
                                },
                                {
                                    div: { id: 'body-editor', class: isEditMode ? '' : 'hidden' }
                                }
                            ]
                        }
                    }
                ]
            }
        };
    }
});

export function initToastEditor(obj, context) {
    const editorEl = document.getElementById('body-editor');
    const viewerEl = document.getElementById('body-viewer');
    const content = (obj.content || '').trim();

    if (!editorInstance && editorEl) {
        editorInstance = new toastui.Editor({
            el: editorEl,
            height: 'auto',
            initialEditType: 'markdown',
            previewStyle: 'vertical',
            customHTMLRenderer
        });
    }

    if (!viewerInstance && viewerEl) {
        viewerInstance = new toastui.Editor.factory({
            el: viewerEl,
            viewer: true,
            height: 'auto',
            customHTMLRenderer
        });
    }

    if (editorInstance) editorInstance.setMarkdown(content);
    if (viewerInstance) viewerInstance.setMarkdown(content);
}

function syncViewMode(context) {
    if (editorInstance && viewerInstance) {
        viewerInstance.setMarkdown(editorInstance.getMarkdown());
    }
    context.setState('isEditMode', false);
}

async function saveNoteContent(context) {
    const note = context.getState('currentNote', null);
    if (!note || !editorInstance) return;
    
    const content = editorInstance.getMarkdown();
    const metadata = typeof note.metadata === 'string' ? JSON.parse(note.metadata) : note.metadata;
    
    const res = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: note.id, content, metadata })
    });
    
    if (res.ok) {
        // Fetch updated note objects
        const objectsRes = await fetch('/api/objects');
        const objects = await objectsRes.json();
        context.setState('objects', objects);
        
        syncViewMode(context);
    }
}
                           {
                                    div: { id: 'body-editor', class: isEditMode ? '' : 'hidden' }
                                }
                            ]
                        }
                    }
                ]
            }
        };
    }
});

export function initToastEditor(obj, context) {
    const editorEl = document.getElementById('body-editor');
    const viewerEl = document.getElementById('body-viewer');
    const content = (obj.content || '').trim();

    if (!editorInstance && editorEl) {
        editorInstance = new toastui.Editor({
            el: editorEl,
            height: 'auto',
            initialEditType: 'markdown',
            previewStyle: 'vertical'
        });
    }

    if (!viewerInstance && viewerEl) {
        viewerInstance = new toastui.Editor.factory({
            el: viewerEl,
            viewer: true,
            height: 'auto'
        });
    }

    if (editorInstance) editorInstance.setMarkdown(content);
    if (viewerInstance) viewerInstance.setMarkdown(content);
}

function syncViewMode(context) {
    if (editorInstance && viewerInstance) {
        viewerInstance.setMarkdown(editorInstance.getMarkdown());
    }
    context.setState('isEditMode', false);
}

async function saveNoteContent(context) {
    const note = context.getState('currentNote', null);
    if (!note || !editorInstance) return;
    
    const content = editorInstance.getMarkdown();
    const metadata = typeof note.metadata === 'string' ? JSON.parse(note.metadata) : note.metadata;
    
    const res = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: note.id, content, metadata })
    });
    
    if (res.ok) {
        // Fetch updated note objects
        const objectsRes = await fetch('/api/objects');
        const objects = await objectsRes.json();
        context.setState('objects', objects);
        
        syncViewMode(context);
    }
}
