import { initToastEditor } from './editor.js';

export const GalleryComponent = (props, context) => ({
    render: () => ({
        div: {
            id: 'note-list',
            children: () => context.getState('objects', []).map(obj => {
                const meta = typeof obj.metadata === 'string' ? JSON.parse(obj.metadata) : obj.metadata;
                
                return {
                    article: {
                        id: `card-${obj.id}`,
                        class: 'card',
                        onclick: () => {
                            if (obj.type === 'query') {
                                context.setState('searchQuery', meta.search_query || "");
                                context.setState('searchType', meta.search_type || "");
                                context.setState('searchTag', meta.search_tag || "");
                                context.setState('advancedSearchOpen', !!(meta.search_type || meta.search_tag));
                                window.dispatchEvent(new Event('trigger-search'));
                            } else {
                                context.setState('currentNote', obj);
                                context.setState('isEditMode', false);
                                setTimeout(() => initToastEditor(obj, context), 0);
                            }
                        },
                        children: () => [
                            { div: { class: 'card-type', text: obj.type } },
                            { h3: { text: obj.title } },
                            obj.type === 'golf' ? { div: { class: 'card-score', children: () => [{ strong: { text: `Score: ${meta.score || 'N/A'}` } }] } } : { div: { class: 'card-content', text: (obj.content || '').substring(0, 100) + '...' } },
                            { div: { class: 'card-location', text: `📍 ${meta.location || 'Unknown'}` } }
                        ]
                    }
                };
            })
        }
    })
});